<?php
namespace Clases;
class Jugada
{

}