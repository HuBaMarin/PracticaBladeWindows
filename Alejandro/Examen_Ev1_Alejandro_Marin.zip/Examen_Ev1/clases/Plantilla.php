<?php
namespace Clases;
class Plantilla
{

}