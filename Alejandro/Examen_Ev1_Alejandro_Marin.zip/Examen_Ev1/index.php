<?php

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<!--RF0 Implementeción de página de bienvenida de index.php-->
<body>
<p>Juego de Mastermind</p>
<p>Este juego consiste en encontrar una secuencia de colores previamente establecida</p>

<form action="jugar.php" method="post">

    <input type="submit" value="Jugar">
</form>
</body>
</html>
